%% UNLOC : UNsupervised particle LOCalization algorithm
%%
%%
%% ALGORITHM AUTHORS:
%%
%% N. BERTAUX, L. DERRODE, A. RABAOUI (1)
%% D. MARGUET, M-C BLACHE, R. FABRE, S. MAILFERT, J. TOUVIER (2)
%% (1): Ecole Centrale Marseille, Aix-Marseille Universite, CNRS, Institut Fresnel, Marseille
%% (2): Centre d'Immunologie de Marseille Luminy, INSERM, CNRS, Aix-Marseille Universite


%% ENG:
%% EXPERT PARAMETER, to launch after UNLOC_param.m
%% EXPERT PARAMETER, to launch after UNLOC_param.m
%% EXPERT PARAMETER, to launch after UNLOC_param.m
%%
%% FR:
%% EXPERT PARAMETER, a lancer apres UNLOC_param.m
%% EXPERT PARAMETER, a lancer apres UNLOC_param.m
%% EXPERT PARAMETER, a lancer apres UNLOC_param.m

%% ==============================================================
%% ================ PROCESSING PARAMETERS ========================
%% ============== YOU CAN MODIFY IN EXPERT MODE =================
%% ==============================================================


%% ====================================
%% Detection, Estimation parameters
%% ====================================


%% maximum deflation number in HD detection/estimation step
%% mini 0, 1 (speed), bien 2,3 (quality) , > 3 no interest
Nb_dft_max = 2 ;

%% if particles too close => bias if 1G optimization (LD)
%% ENG: as from LD_limit, transition to N gaussian estimation (HD)
%% FR: a partir de LD_limit passage a estimateur N gaussiennes (HD)
%% LD_limit>5.0 no interest and time and memory ++
LD_limit = 5.0*r0 ;

%% ENG:
%% limitation of calculating complexity (calculation time and limited memory)
%% particle groups with cardinal > NB_NG_MAX
%% 1: are split again with smaller LD_limit (coef_red_dmin*LD_limit)
%% 2: if still groups > NB_NG_MAX, these groups are split again with a distance coef_red_dmin^2*LD_limit
%% 3: and if still groups > NB_NG_MAX, then they are geometrically divided in parts ~NB_NG_MAX.
%% In this last case, LD_limit constraint (even lighter) is no more validated (at the parts borders)
%% coef_red_dmin parameter is fixed close to 0.9-0.88 so the LD_limit distance range from :
%% 5*r0, 4.5*r0 and 4.0*r0 (~4.0*r0 limited value assuring the non/low apparition of bias)
%% comment1 : case 3 sends back a warning
%% comment2 : NB_NG_MAX=500 limit works for workstations (4Go/cores) and
%% is a priori never active for data of density < 3 part/�m2
%%
%% FR:
%% limitation de la complexite calculatoire (temps calculs et memoire limitee)
%% les groupes de particules de cardinal > NB_NG_MAX
%% 1: sont redecoupes avec une distance LD_limit plus petite (coef_red_dmin*LD_limit)
%% 2: si encore des groupes > NB_NG_MAX, ces groupes sont redecoupes avec une distance coef_red_dmin^2*LD_limit
%% 3: et si encore des groupes > NB_NG_MAX, alors ils sont geometrique scindes en parties ~NB_NG_MAX.
%% Dans ce dernier cas la contrainte LD_limit (meme allegee) n'est plus verifiee (a la frontiere des parties)
%% le parametre coef_red_dmin est fixee proche de 0.9-0.88 afin que la distance LD_limit
%% varie de 5*r0, 4.5*r0 et 4.0*r0 (~4.0*r0 valeur limite garantissant la non/faible apparition de biais)
%% note1 : le cas 3 renvoie un warning
%% note2 : la limite NB_NG_MAX=500 foncionne pour des workstations (4Go/cores) et
%% n'est a priori jamais active pour des datas de densite < 3 part/�m2
%% note3 : la limite NB_NG_MAX=200 ok pour une densite jusqu'a 2 part/micron2
nb_nG_max = 200 ;
coef_red_dmin = 0.88 ;


%% ENG: window of estimation window (odd and depending on r0)
%% FR: fenetre de la fenetre pour estimation (impaire et depend de r0)
%% wn size must be odd and enough large for complet PSF, don't modify this line
if (flag_r==0)  wn = 2*round(r0*3.3)+1 ; else  wn = 2*round(r0max_wn*3.3)+1 ; end%if

%% ENG:
%% detection threshold according to the probability of false alarm (pfa)
%% pfa value         1E-2  1E-3  1E-4 1E-5 1E-6 1E-7
%% threshold(pfa)     6    11     15   20   24   28
%%
%% FR:
%% seuil de detection fixant la probabilite de fausse alarme (pfa)
%% valeur pfa   1E-2  1E-3  1E-4  1E-5 1E-6 1E-7
%% seuil(pfa)    6    11     15    20   24   28
pfa     = 24 ; %% >=24
pfa_res = 15 ; %% <= pfa


%% ===================================
%% mode debug flags
%% ===================================
%% DEBUG:    [0/1] more info in output file (csv)
%% verbose2: [0/1] more info in terminal
%% keep_ko:  keep all particles after estimation (1G)
DEBUG  = 0 ;
verbose2 = 0 ;
keep_ko = 0 ;
%%
%% [0/1] for compat with imagej plugin (ex close figures)
%% set unlocijplugin=1 for run with imagej plugin
unlocijplugin = 1 ;


%% ENG:
%% ===================================
%% configuration parameters for exportation of output data
%% ===================================
%%
%% the 3 next variables must be written in this format:
%%
%% textparam     = ['name param1;',         'name param2;'           ...] ;
%% templateparam = ['C template format_1;', 'C template format_2;',  ...] ;
%% listparam     = [ param_t_name_1,         param_t_name_2,         ...] ;
%%
%% with detection parameters in list:
%%  param_t_tps           %% time ind (tracking: disappearance ind)
%%  param_t_i             %% trajectory position in pixel
%%  param_t_j             %% trajectory position in pixel
%%  param_t_sig2          %% ij variance of trajectory
%%  param_t_r0
%%  param_t_sig2_noise    %% noise variance at the last detection
%%  param_t_m	          %% estimated background level (including darklevel)
%%  param_t_alpha         %% particle intensity, or of last detection (stat on alpha)
%%

%% convert_var_to_std: [0/1] export variance parameter in standard deviation (std=sqrt(var))
%% this option concern  param_t_sig2 and param_t_sig2_noise only
%% !!! : provide text and template according to this option
%%
%% FR:
%% ===================================
%% parametre de config pour l'exportations des donnees de sortie
%% ===================================
%%
%% the 3 next variables must be writed with format:
%%
%% textparam     = ['name param1;',         'name param2;'           ...] ;
%% templateparam = ['C template format_1;', 'C template format_2;',  ...] ;
%% listparam     = [ param_t_name_1,         param_t_name_2,         ...] ;
%%
%% with detection parameters in list:
%%  param_t_tps           %% ind temps (tracking: ind de disparition)
%%  param_t_i             %% position de la trajectoire en pixel
%%  param_t_j             %% position de la trajectoire en pixel
%%  param_t_sig2          %% variance ij de la trajectoire
%%  param_t_r0
%%  param_t_sig2_noise    %% variance du bruit a la derniere detection
%%  param_t_m	          %% niveau du fond estimee (inclus darklevel)
%%  param_t_alpha         %% intensite particule, ou de la derniere detection (stat sur alpha)
%%

%% convert_var_to_std: [0/1] export variance parameter in standard deviation (std=sqrt(var))
%% this option concern  param_t_sig2 and param_t_sig2_noise only
%% !!! : provide text according to this option
convert_var_to_std = 1 ;

%textparam     = ['time;',     'position_i;','position_j;','var_error_position_ij;','alpha;'    ,  'std_bg_noise;'] ;
%templateparam = ['%d;',       '%.3f;',      '%.3f;',      '%.5f;',                 '%.0f;',       '%.1f;'] ;
textparam     = ['time;',     'position_i;','position_j;','std_error_position_ij;','alpha;'    ,  'std_bg_noise;'   ,'r0;'] ;
templateparam = ['%d;',       '%.3f;',      '%.3f;',      '%.3f;',                 '%.0f;',       '%.1f;'           ,'%.3f;'] ;
listparam     = [param_t_tps, param_t_i,    param_t_j,    param_t_sig2,            param_t_alpha, param_t_sig2_noise , param_t_r0] ;

%% write and read data in ascii or RAW in cvs file
%% RAW is unreadable for human but much much faster !
%% if Data_ascii is fixed at 0, fixe convert_var_to_std==0 too (for speed)
Data_ascii = 1 ;

