%% UNLOC : UNsupervised particle LOCalization algorithm
%%
%%
%% ALGORITHM AUTHORS:
%%
%% N. BERTAUX, L. DERRODE, A. RABAOUI (1)
%% D. MARGUET, M-C BLACHE, R. FABRE, S. MAILFERT, J. TOUVIER (2)
%% (1): Ecole Centrale Marseille, Aix-Marseille Universite, CNRS, Institut Fresnel, Marseille
%% (2): Centre d'Immunologie de Marseille Luminy, INSERM, CNRS, Aix-Marseille Universite


%% ===================================
%% inputs UNLOC parameters
%% ===================================

stkrange_begin      = 0 
stkrange_end        = 0
rep_in= 'output/';
OUTPUT_FOLDER='output/' ;
m_data_file=['Cell.tif'];
output_file='Cell.csv';


%% ====================================
%% Parallel process parameter
%% use runparallel=0 to run without the Parallel Computing Toolbox
%%
%% minimal Workstation configuration for data of size < 512x512 pixels :
%%    CPU:  cores >= 4 (physical, ie not including hyperthreading)
%%    CPU:  Freq > 3.0Ghz
%%    CPU:  L3 cache >= 2.0Mo/cores
%%    RAM:  4Go *nb_cores
%%
%% note : octave version does not have parallel capabilities (parfor)
%%        run UNLOC with option runparallel=0
%% ====================================

%% 0:off, 1:auto, N:fixed thread number (limited to number of cores on the local machine)
runparallel = 1 ;

%% ====================================
%% Detection, Estimation parameters
%% ====================================

%% ===================================
%% ROI parameters
%% ===================================
%% CROP_ON: 0/1 : on/off
%% ENG:
%% RECAL_CROP: 0/1 : registration of particle coordinates according to the full field image (otherwise, reference in (1,1))
%%
%% FR:
%% RECAL_CROP: 0/1 : recalage des coordonnees des particules par rapport à l'image plein champs (sinon, reference en (1,1))
CROP_ON = 0 ;
ROI_mi = 1 ;
ROI_mj = 1 ;
ROI_Mi = 512 ;
ROI_Mj = 512 ;
RECAL_CROP = 0 ;

%% ENG:
%% HDmode : available modes from low density (mono-psf) to very high density (multi-psf + model order estimation)
%% -1:  UFUL,   low density (<0.1 part/microns^2), fixed PSF size
%% 0:   LD,     low density (<0.1 part/microns^2)
%% 1:   HDs,    high-speed, medium density (<0.5 part/microns^2)
%% 2:   HD,     high density (<1 part/microns^2) (pre-defined mode, equiv mode3 1 passe)
%% 3:   HD+,    very high density (>1 part/microns^2, maxi 3 part/microns^2)
%%
%%
%%
%% HDmode 0 :     LD detection : (equiv : MTT2008, gaussian PSF)
%%                   --> detection glrt 0G/1G => estimation 1G
%%
%%
%% HDmode 1 :     detection HDs high-speed
%%                   --> background estimation (on temporal window (background bleaching) or frame by frame)
%%                   --> HD detection (known background: mean/var), maximums selection on deconvolution of glrt
%%                      --> detection of  Nx1G neighbours (distance between 2x1G < 5r0 + group research)
%%                          --> NG neighbours  => estimation NG
%%                          --> 1G alone       => estimation 1G
%%
%%
%% modes 2 and 3, designed for TIRF mode (very high density with estimaton of particle number)
%%
%% HDmode 2 :     detection HD (pre-defined mode, equiv. mode3 with 1 single pass)
%%                   --> background estimation (on temporal window (background bleaching) or frame by frame)
%%                   --> HD detection (known background: mean/var), maximums selection on deconvolution of input image
%%                        --> detection of Nx1G neighbours (distance between 2x1G < 5r0 + group research)
%%                             --> NG neighbours  => NG estimation + reduction of N by GLRT
%%                             --> 1G alone       => estimation 1G
%%
%%
%% HDmode 3 :     detection HD+
%%                   --> background estimation (on temporal window (background bleaching) or frame by frame)
%%                   --> Deflation loop (increase of particles number)
%%                       --> HD detection (known background: mean/var), maximums selection on deconvolution of input image
%%                          --> detection of Nx1G neighbours (distance between 2x1G < 5r0 + group research)
%%                             --> NG neighbours  => NG estimation + reduction of N by GLRT
%%                             --> 1G alone       => estimation 1G
%%                   --> end deflation loop
%%



%% ===================================
%% UFUL/LD/HDs/HD/HD+ mode and PSF size estimation flags
%% ===================================
%% HDmode: -1,0,1,2,3
HDmode = 0 ;
%% flag_r: 0 ou 1 (tirf used mode flag_r=0, classic dSTORM used mode flag_r=1)
%% HDmode -1 (uful) work only with flag_r==0 (wait futur version)
flag_r = 1 ; 

%% ===================================
%% background estimation: only for HD mode (ie. HDmode= 1 2 3)
%% ===================================
%%
%% ENG:
%% BGmode=0 : background model as constant and estimation frame by frame
%% BGmode=1 : background model as 2D low frequency surface and estimation frame by frame
%% BGmode=2 : background model as 2D high frequency surface and bleaching (estimation on time window)
%% comment : function on temporal window (ie BGmode=2) can require lots of memory if image size >512x512
%% BGmode: 0,1,2
BGmode = 1 ;
Size_window_for_BGmode2 = 100 ; 

%% ===================================
%% PSF reference size parameter (in focal plan) and model sampled or integrated
%% ===================================
%%% ENG: half width of psf (dye) in focal plane (min value)
%%% FR: demi largeur de la psf (dye) dans le plan focal (valeur min)
r0 = 1.25 ; 

%% r0max_wn used if (flag_r==1), bornes max on r0 optimization (=>definition broader wn)
r0max_wn = 2.0*r0 ;


%% for HDmode = 1/2/3
%% PSF_model==0 : gaussian PSF (sampled)
%% PSF_model==1 : integrated gaussian PSF (pixel camera effect)
PSF_model = 1 ;





%% ===================================
%% Cursors for Live Display
%% ===================================
%% DISPLAY: [0/1] images output with detection/localization/precision/residues visualization
DISPLAY = 0 ;
coef_std = 20 ;
cursor = 1 ;
coef_blink = 0 ;
zoom_pixel = 3 ;
zoom_cursor = 3 ;


%% ===================================
%% Pixel size for density estimation and display
%% ===================================
pixel2micron = 0.1 ;
%%pixel2micron = 0.160 ;



%% ====================================
%% camera parameters
%% THESE INFORMATIONS ARE ONLY USE FOR ESTIMATION OF LOCALIZATION ERRORS
%% IF YOU CANNOT PROVIDE CORRECT VALUES OF ALL THESES PARAMETRES
%% SET EMCCD_gain<=0 TO FORCE GAUSSIAN MODE FOR ESTIMATIONS ERRORS
%%
%% Default is EMCCD_gain==-1
%%
%% note: for HDmode >1 the localization errors are provide by HD BCR 
%% ====================================

%% ENG:
%% EMCDD camera parameters (non additive noise)
%% - if data are close to darklevel (background) then
%% this value has to be known.
%% - data have to be in the linear zone of the camera (<Vmax),
%% otherwise predictions on precision will be wrong => tracking pb
%% for example, on ANDOR iXon+ limit is around Vmax=6000 (camera output value)
%% for ANDOR iXon+ camera
%% gain soft   ->   Gaim EMCCD
%%   100       ->   1
%%   200       ->   2
%%   255       ->   2.5
%% darklevel==100 for ANDOR iXon+
%%
%%
%% for CMOS camera, set EMCCD_gain = 0.5 (poisson noise)
%%
%% If theses values are unkown, set EMCCD_gain=-1 

Darklevel      = 0.0 ;
EMCCD_gain     = 0.0 ;
Amplification  = 1.0 ;
