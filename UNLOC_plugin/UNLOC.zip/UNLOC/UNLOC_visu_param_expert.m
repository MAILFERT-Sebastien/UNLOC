%% UNLOC : UNsupervised particle LOCalization algorithm
%%
%%
%% ALGORITHM AUTHORS:
%%
%% N. BERTAUX, L. DERRODE, A. RABAOUI (1)
%% D. MARGUET, M-C BLACHE, R. FABRE, S. MAILFERT, J. TOUVIER (2)
%% (1): Ecole Centrale Marseille, Aix-Marseille Universite, CNRS, Institut Fresnel, Marseille
%% (2): Centre d'Immunologie de Marseille Luminy, INSERM, CNRS, Aix-Marseille Universite
