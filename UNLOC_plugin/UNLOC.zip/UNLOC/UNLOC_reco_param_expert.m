%% UNLOC : UNsupervised particle LOCalization algorithm
%%
%%
%% ALGORITHM AUTHORS:
%%
%% N. BERTAUX, L. DERRODE, A. RABAOUI (1)
%% D. MARGUET, M-C BLACHE, R. FABRE, S. MAILFERT, J. TOUVIER (2)
%% (1): Ecole Centrale Marseille, Aix-Marseille Universite, CNRS, Institut Fresnel, Marseille
%% (2): Centre d'Immunologie de Marseille Luminy, INSERM, CNRS, Aix-Marseille Universite


%% ENG:
%% EXPERT PARAMETER, to launch after UNLOC_param.m
%% EXPERT PARAMETER, to launch after UNLOC_param.m
%% EXPERT PARAMETER, to launch after UNLOC_param.m
%% FR:
%% EXPERT PARAMETER, a lancer apres UNLOC_param.m
%% EXPERT PARAMETER, a lancer apres UNLOC_param.m
%% EXPERT PARAMETER, a lancer apres UNLOC_param.m

%% ==============================================================
%% ================ PROCESSING PARAMETERS ========================
%% ============== YOU CAN MODIFY IN EXPERT MODE =================
%% ==============================================================



%% ====================================
%% traking parameters
%% ====================================

%% ENG:
%% minimum SNR threshold (in dB) and probability density (PD) threshold for reconnected particles (dye) that blink
%% these two parameters are linked => expert
%%             PD =  99.99 99.9  99.5   99   98  95   90   80
%% reconnect_pd_threshold =  18.5  13.8  10.8  9.2  7.8   6  4.6  3.2
%% thresholds can be calculated from threshold = chi2inv(pd,2) of statistic toolbox
% reconnect_pd_threshold:  Expert user choice (def 6)
% SNRdBmin_track:  Expert user choice (def 20]
% Backward:        flag 0/1 % Expert user choice (def= HDmode==1 )
%%
%% FR:
%% seuil en dB sur le RSB mini et seuil en PD sur le tracking de particules (dye) qui blink
%% ces deux parametres sont lies => expert
%%             PD =  99.99 99.9  99.5   99   98  95   90   80
%% reconnect_pd_threshold =  18.5  13.8  10.8  9.2  7.8   6  4.6  3.2
%% les seuil peuvent etre calcul a partir de seuil = chi2inv(pd,2) de la toolbox statistic
% reconnect_pd_threshold:  Expert choix utilisatieur (def 6)
% SNRdBmin_track:  Expert choix utilisatieur (def 20]
% Backward:        flag 0/1 % Expert choix utilisateur (def= HDmode==1 )
reconnect_pd_threshold = 6  ;
SNRdBmin_track = 20 ;
Backward = HDmode>=2 ;


%% ENG:
%% ESTIMATED DRIFT BY REFERENCE BEADS
%% number of successive presences (ON) to declare a particle as reference
%% for drift measurement
%% reconnect_pd_threshold  <7.8 <6  <4.6  <3.2
%% max_particle_ON_ref    = 50  20   10    5
%% max_particle_ON_ref  = round(inv(1-chi2cdf(reconnect_pd_threshold,2))) ; % with statistic toolbox
%% FR:
%% DRIFT ESTIMEE PAR DES BILLES de REFERENCE
%% nombre de presence (ON) successives pour declarer une partilcule comme reference
%% pour la mesure du drift
%% reconnect_pd_threshold  <7.8 <6  <4.6  <3.2
%% max_particle_ON_ref    = 50  20   10    5
%% max_particle_ON_ref  = round(inv(1-chi2cdf(reconnect_pd_threshold,2))) ; % with statistic toolbox
max_particle_ON_ref = 15 ;

reconnect_pd_threshold_ref = 13.8 ; % (>reconnect_pd_threshold, def:13.8)
%% ENG:
%% correction on sig2_ref to go from threshold of pd of reconnect_pd_threshold to reconnect_pd_threshold_ref
%% under hypothesis that sig2_ref~=sig2_part (hypothesis ok for reference that does not blink)
%% FR:
%% correction sur sig2_ref pour passer du seuil de pd de reconnect_pd_threshold a reconnect_pd_threshold_ref
%% sous hypothese que sig2_ref~=sig2_part (hypothese ok pour reference qui ne blink pas)
corr_sig2_ref_4_pd_track = 2*reconnect_pd_threshold_ref/reconnect_pd_threshold -1 ;

%% ENG:
%% tracking of reference beads
%% add_var_drift: increase of variance to take into account high impulsive drift
%% or/and NR particles in HD  or/and in case of beads with very high SNR
%% FR:
%% tracking des billes de references
%% add_var_drift: majoration de la variance pour la prise en compte de drift impulsionnel important
%% ou/et particules NR en HD  ou/et dans les cas de billes � tres fort SNR
add_var_drift = 0.0006 ;

%% ENG:
%% ===================================
%% config parameters for the exportation of output data
%% ===================================
%%
%% the 3 next variables must be written in this format:
%%
%% textparam     = ['name param1;',         'name param2;'           ...] ;
%% templateparam = ['C template format_1;', 'C template format_2;',  ...] ;
%% listparam     = [ param_t_name_1,         param_t_name_2,         ...] ;
%%
%% with detection parameters in list:
%%  param_t_tps           %% tracking state   : ind disappearance time
%%  param_t_i             %% trajectory position in pixel
%%  param_t_j             %% trajectory position in pixel
%%  param_t_sig2          %% ij variance of trajectory
%%  param_t_r0
%%  param_t_sig2_noise    %% noise variance at the last detection
%%  param_t_m	          %% estimated background level (including darklevel)
%%  param_t_alpha         %% particle intensity, or of last detection (stat on alpha)
%%
%% and  with tracking parameters in list:
%%   comment: stat info intensity
%%         N = "param_t_etat_sum_on"
%%         mean_alpha = "param_t_alpha_sum" / N
%%         var_alpha  = "param_t_alpha_sum2" / N  - mean_alpha^2
%%  param_t_num
%%  param_t_alpha_max     %% stat on alpha : intensity max
%%  param_t_alpha_sum     %% stat on alpha : sum of intensities (calculation of mean, var)
%%  param_t_alpha_sum2    %% stat on alpha : square sum of intensities (calculation of var)
%%  param_t_etat          %% tracking state : State >0 => ON, <0 => blink/OFF, <max_particle_OFF => END
%%  param_t_etat_sum_on   %% tracking state : sum of states >0
%%  param_t_etat_nb_blk   %% tracking state : number of blink
%%  param_t_tps_start     %% ind appearance time
%%  param_t_reference     %% drift management:  position of previous particle
%%  param_t_pos_i         %% drift management : position of particle at t-1
%%  param_t_pos_j         %% drift management : position of particle at t-1
%%  param_t_sig2_pos      %% drift management : ij variance of particle at t-1

%% convert_var_to_std: [0/1] export variance parameter in standard deviation (std=sqrt(var))
%% this option concern param_t_sig2 and param_t_sig2_noise only
%% !!! : provide text and template according to this option

%% FR:
%% ===================================
%% parametre de config pour l'exportations des donnees de sortie
%% ===================================
%%
%% the 3 next variables must be writed with format:
%%
%% textparam     = ['name param1;',         'name param2;'           ...] ;
%% templateparam = ['C template format_1;', 'C template format_2;',  ...] ;
%% listparam     = [ param_t_name_1,         param_t_name_2,         ...] ;
%%
%% with detection parameters in list:
%%  param_t_tps           %% tracking state   : ind temps de disparition
%%  param_t_i             %% position de la trajectoire en pixel
%%  param_t_j             %% position de la trajectoire en pixel
%%  param_t_sig2          %% variance ij de la trajectoire
%%  param_t_r0
%%  param_t_sig2_noise    %% variance du bruit a la derniere detection
%%  param_t_m	          %% niveau du fond estimee (inclus darklevel)
%%  param_t_alpha         %% intensite particule, ou de la derniere detection (stat sur alpha)
%%
%% and  with tracking parameters in list:
%%   note: stat info intensite
%%         N = "param_t_etat_sum_on"
%%         mean_alpha = "param_t_alpha_sum" / N
%%         var_alpha  = "param_t_alpha_sum2" / N  - mean_alpha^2
%%  param_t_num
%%  param_t_alpha_max     %% stat sur alpha : intensite max
%%  param_t_alpha_sum     %% stat sur alpha : somme des intensite (calcul mean, var)
%%  param_t_alpha_sum2    %% stat sur alpha : somme des intensites au carre (calcul, var)
%%  param_t_etat          %% tracking state   : Etat >0 => ON, <0 => blink/OFF, <max_particle_OFF => END
%%  param_t_etat_sum_on   %% tracking state   : sum des etat >0
%%  param_t_etat_nb_blk   %% tracking state   : nombre de blink
%%  param_t_tps_start     %% ind temps d'apparition
%%  param_t_reference     %% gestion du drift : position de la precedente particule
%%  param_t_pos_i         %% gestion du drift : position de la particule a t-1
%%  param_t_pos_j         %% gestion du drift : position de la particule a t-1
%%  param_t_sig2_pos      %% gestion du drift : variance ij de la particule a t-1

%% convert_var_to_std: [0/1] export variance parameter in standard deviation (std=sqrt(var))
%% this option concern  param_t_sig2 and param_t_sig2_noise only
%% !!! : provide text and template according to this option
convert_var_to_std = 1 ;

textparam     = ['num_traj;', 'time_end;', 'time_start;',     'position_i;','position_j;','std_error_position_ij;','sum_on;',           'nb_blink;',         'alpha_sum;'] ;
templateparam = ['%d;',       '%d;',       '%d;',             '%.3f;',      '%.3f;',      '%.3f;',                 '%d;',               '%d;',               '%.0f;'] ;
listparam     = [param_t_num, param_t_tps, param_t_tps_start, param_t_i,    param_t_j,    param_t_sig2,            param_t_etat_sum_on, param_t_etat_nb_blk, param_t_alpha_sum] ;
